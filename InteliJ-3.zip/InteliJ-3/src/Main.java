import java.awt.Color;

import itumulator.executable.DisplayInformation;
import itumulator.executable.Program;
import itumulator.world.Location;

public class Main {

    public static void main(String[] args) {

    }
}